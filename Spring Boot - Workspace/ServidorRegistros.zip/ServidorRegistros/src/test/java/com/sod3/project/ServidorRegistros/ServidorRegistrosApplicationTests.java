package com.sod3.project.ServidorRegistros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServidorRegistrosApplicationTests {

	@Test
	void contextLoads() {
	}

}

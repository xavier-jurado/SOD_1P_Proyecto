package com.sod3.project.circuitbreakerbookstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CircuitBreakerBookstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.sod3.project.circuitbreakerreading;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CircuitBreakerReadingApplicationTests {

	@Test
	void contextLoads() {
	}

}
